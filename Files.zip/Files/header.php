 <!-- Start: page-top-outer -->
        <div id="page-top-outer">

            <!-- Start: page-top -->
            <div id="page-top">



                <div class="clear"></div>

            </div>
            <!-- End: page-top -->

        </div>
        <!-- End: page-top-outer -->

        <div class="clear">&nbsp;</div>

        <!--  start nav-outer-repeat................................................................................................. START -->
        <div class="nav-outer-repeat">
            <!--  start nav-outer -->
            <div class="nav-outer">

                <!-- start nav-right -->
                <div id="nav-right">

                    <div class="nav-divider">&nbsp;</div>
                    <div class="showhide-account"><img src="imagesadminpage/shared/nav/nav_myaccount.gif" width="93" height="14" alt="" /></div>
                    <div class="nav-divider">&nbsp;</div>
                    <a href="log-out.php" id="logout"><img src="imagesadminpage/shared/nav/nav_logout.gif" width="64" height="14" alt="" /></a>
                    <div class="clear">&nbsp;</div>


                </div>
                <!-- end nav-right -->


                <!--  start nav -->
                <div class="nav">
                    <div class="table">

                        <ul class="select"><li><a href="adminhome.php"><b>Home</b></a>

                            </li>
                        </ul>

                        <div class="nav-divider">&nbsp;</div>



                        <ul class="select"><li><a href="#nogo"><b>User Login Setup</b></a>

                                <div class="select_sub">
                                    <ul class="sub">
                                        <li><a href="createlogin.php">Create User Login</a></li>
                                        <li><a href="delete-user.php">Edit / Delete User Login</a></li>
                                    </ul>
                                </div>

                            </li>
                        </ul>

                        <div class="nav-divider">&nbsp;</div>

                        <ul class="select"><li><a href="#nogo"><b>Report</b></a>

                                <div class="select_sub">
                                    <ul class="sub">
                                        <li><a href="#nogo">Full Report</a></li>
                                        <li><a href="#nogo">Survey Query</a></li>
                                        <li><a href="#nogo">Delete Report</a></li>

                                    </ul>
                                </div>

                            </li>
                        </ul>

                        <div class="nav-divider">&nbsp;</div>


                        <div class="clear"></div>
                    </div>
                    <div class="clear"></div>
                </div>
                <!--  start nav -->

            </div>
            <div class="clear"></div>
            <!--  start nav-outer -->
        </div>
        <!--  start nav-outer-repeat................................................... END -->
